import sqlite3
from django.shortcuts import render, redirect, HttpResponse

from .utils import DataBase, get_cals, get_bzu, get_meals_calls, recommended_water

db = DataBase()

def data(request):
    flag, id = db.islogin(request.META["HTTP_USER_AGENT"])
    if flag: 
        return HttpResponse("45")
    else:
        return HttpResponse("None")

def index(request):
    flag, id = db.islogin(request.META["HTTP_USER_AGENT"])
    if flag: 
        data = db.get_user_data(id)
        calls = get_cals(data[0][3], data[0][4], data[0][2], data[0][5], data[0][6])
        b, z, u = get_bzu(calls)
        meals = get_meals_calls(calls)
        user_meals_ids, l = db.get_all_user_meals(id)
        nutrients, eaten_calls = db.get_dishes_bzu(user_meals_ids)
        context = {
            'calls': calls,
            'eaten_calls': int(sum(eaten_calls)),
            'b': b,
            'z': z,
            'u': u,
            'eaten_b': int(nutrients[0]),
            'eaten_z': int(nutrients[1]),
            'eaten_u': int(nutrients[2]),
            'todaycalls': round(float(calls - sum(eaten_calls)), 2),
            'water': round(float(recommended_water(data[0][4])), 2),
            'l': l,
            'todaywater': round(float(recommended_water(data[0][4])-l), 2),
            'breakfast': meals[0],
            'lunch': meals[1],
            'dinner': meals[2],
            'snack': meals[3],
            'calls_breakfast': int(eaten_calls[0]),
            'calls_lunch': int(eaten_calls[1]),
            'calls_dinner': int(eaten_calls[2]),
            'minset': str(round(l-0.2,2)).replace(".", "/"),
            'maxset': str(round(l+0.2,2)).replace(".", "/")
        }
        return render(request, "home.html", context)
    else: 
        return redirect("/login/")
def setwater(request, num1,num2):
    flag, id = db.islogin(request.META["HTTP_USER_AGENT"])
    if not flag:
        return redirect("/login/")
    db.add_meals(num1+(num2/100), id, "water")
    return redirect("/home/")

def menu(request, name):
    meals = db.get_food()
    return render(request, "menu.html", {'dishes': meals, 'name': name})

def addmeals(request, name):
    flag, id = db.islogin(request.META["HTTP_USER_AGENT"])
    if not flag:
        return redirect("/login/")
    dishes = request.POST
    dishe = dict(dishes)
    dish = list(dishe['dishes'])
    db.add_meals(dish, id, name)
    print(dish)
    return redirect("/")
    




















def login(request):
    return render(request, "signin.html")

def logup(request):
    return render(request, "signup.html")

def checklogin(request):
    log = request.POST.get("login")
    pas = request.POST.get("password")
    user_agent = request.META["HTTP_USER_AGENT"]

    if db.checklogin(log, pas, user_agent):
        return redirect("/")
    else:
        return redirect("/login/")

def setlogin(request):
    user_agent = request.META["HTTP_USER_AGENT"]
    login = request.POST.get("login")
    password = request.POST.get("password")
    name = request.POST.get("name")
    birthday = request.POST.get("birthday")
    height = request.POST.get("height")
    weight = request.POST.get("weight")
    gender = request.POST.get("gender")
    activity = request.POST.get("activity")
    db.register(user_agent, login, password, name, birthday, height, weight, gender, activity)
    return redirect("/")


def logout(request):
    flag, ID = db.islogin(request.META["HTTP_USER_AGENT"])
    if flag:
        db.cur.execute('UPDATE Users SET BrowData = ? WHERE ID = ?', (None, ID))
        db.conn.commit()

    return redirect("/")


def page404(request, exception):
    return HttpResponse("040")