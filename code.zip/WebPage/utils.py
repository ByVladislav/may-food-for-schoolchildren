import sqlite3
import ast

from datetime import datetime, date

from django.shortcuts import render, redirect

class DataBase:
	def __init__(self):
		global conn, cur
		conn = sqlite3.connect('database.db', check_same_thread=False)
		cur = conn.cursor()

		self.conn = conn
		self.cur = cur

		cur.execute('''
		CREATE TABLE IF NOT EXISTS users (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			login TEXT,
			password TEXT,
			browdata TEXT
		)
		''')

		cur.execute('''
		CREATE TABLE IF NOT EXISTS userdata (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			FIO TEXT,
			birtday TEXT,
			height INTEGER,
			weight INTEGER,
			gender TEXT,
			activity INTEGER
			)''')

		cur.execute('''
		CREATE TABLE IF NOT EXISTS food (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT,
			mass INTEGER,
			protein INTEGER,
			fat INTEGER,
			carbs INTEGER,
			calls INTEGER
		)
		''')

		cur.execute('''
		CREATE TABLE IF NOT EXISTS userDiary (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			user_id INTEGER,
			date TEXT,
			breakfast INTEGER,
			lunch INTEGER,
			dinner INTEGER,
			snack INTEGER,
			water REAL,
			FOREIGN KEY (user_id) REFERENCES users(id)
		)
		''')

		# conn_food = sqlite3.connect('example.db', check_same_thread=False)
		# cur_food = conn_food.cursor()

		# cur_food.execute('SELECT * FROM example_table')
		# rows = cur_food.fetchall()

		# for row in rows:
		# 	cur.execute('INSERT INTO food VALUES (?, ?, ?, ?, ?, ?, ?)', row)
		# 	conn.commit()

		conn.commit()

	def islogin(self, user_agent):
		cur.execute('SELECT id FROM users WHERE browdata == ?', (user_agent,))
		results = cur.fetchall()
		if results == list():
			return False, 0
		else:
			return True, results[0][0]


	def checklogin(self, login, password, user_agent):
		cur.execute('SELECT password FROM users WHERE login == ?', (login,))
		results = cur.fetchall()
		if results == list():
			return False
		else:
			if results[0][0] == password:
				cur.execute('UPDATE users SET browdata = ? WHERE login = ?', (user_agent, login))
				conn.commit()
				return True
			else:
				return False


	def get_meals(self, id):
		cur.execute('SELECT * FROM userDiary WHERE user_id == ?', (id,))
		results = cur.fetchall()
		return results

	def get_food(self):
		cur.execute('SELECT * FROM food')
		results = cur.fetchall()
		return results

	def get_user_data(self, id):
		cur.execute('SELECT * FROM userdata WHERE id == ?', (id,))
		results = cur.fetchall()
		return results

	def register(self, user_agent, login, password, name, birthday, height, weight, gender, activity):
		cur.execute('SELECT * FROM users WHERE login == ?', (login,))
		results = cur.fetchall()
		if results == list():
			if password != "" and password != None:
				cur.execute('INSERT INTO users (login, password, browdata) VALUES (?, ?, ?)',
						(login, password, user_agent))
				conn.commit()
				id = cur.execute('SELECT id FROM users WHERE login == ?', (login,)).fetchone()[0]
				print(id)
				cur.execute('INSERT INTO userdata (id, FIO, birtday, height, weight, gender, activity) VALUES (?, ?, ?, ?, ?, ?, ?)',
						(id, name, birthday, height, weight, gender, activity))
				conn.commit()
			else:
				return redirect("/signup/")
		else:
			return redirect("/signup/")
	
	def add_meals(self, meals, user_id, meal_type):
		today_date = date.today()
		row = cur.execute('SELECT * FROM userDiary WHERE user_id == ? AND date == ?', (user_id, today_date)).fetchone()

		if not row:	
			cur.execute('INSERT INTO userDiary (user_id, date, breakfast, lunch, dinner, snack, water) VALUES (?, ?, ?, ?, ?, ?, ?)', (user_id, today_date, '[]', '[]', '[]', '[]', 0))
			conn.commit()

		if meal_type:
			meals = str(meals)
			cur.execute(f'UPDATE userDiary SET {meal_type} = ? WHERE user_id = ? AND date = ?', (meals, user_id, today_date))
			conn.commit()

	def get_all_user_meals(self, user_id):
		today_date = date.today()
		results = []
		meals_ids = cur.execute('SELECT breakfast, lunch, dinner, snack, water FROM userDiary WHERE user_id == ? AND date == ?', (user_id, today_date))
		l = 0
		for meals in meals_ids:
			l = float(meals[4])
			for meal in meals:
				if meal == l: continue
				results.append(ast.literal_eval(meal))
		return results, l

	def get_dishes_bzu(self, ids):
		proteins = 0
		fat = 0
		carbs = 0
		calls=[0]*4
		i=0
		for	id in ids:
			for ID in id:
				cur.execute('SELECT protein, fat, carbs, calls FROM food WHERE id == ?', (int(ID),))
				meal = cur.fetchone()
				proteins += meal[0]
				fat += meal[1]
				carbs += meal[2]
				calls[i]+= meal[3]
			i+=1
		return [proteins, fat, carbs], calls

def get_cals(weight, height, birthday, gender, tdee):
	age = calculate_age(birthday)
	if gender == 'man':
		callories = 10 * weight + 6.25 * height - 5 * age + 5
		calls = callories * tdee 
		return int(calls)
	elif gender == 'woman':
		callories = 10 * weight + 6.25 * height - 5 * age - 161
		calls = callories * tdee
		return int(calls)
	
def recommended_water(weight):
	return weight * 0.03

def calculate_age(birthdate):
	birthdate = datetime.strptime(birthdate, "%Y-%m-%d").date()
	today = datetime.now().date()
	age = today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))

    # Не забываем о днях рождения, приходящихся на високосный день каждые четыре года!
	if birthdate.month == 2 and birthdate.day == 29:
		try:
			leap_year_birthday = birthdate.replace(year=today.year)
		except ValueError:
            # Если в этом году нет 29 февраля, празднование происходит 28 февраля
			leap_year_birthday = birthdate.replace(year=today.year, day=28)

		if today < leap_year_birthday:
			age -= 1  # Отмечаем эту дату заново, время для празднования ещё не пришло!
	return age

def get_bzu(calls):
	protein = calls * 0.3
	fat = calls * 0.3
	carbohydrates = calls * 0.4
	return int(protein), int(fat), int(carbohydrates)

def get_meals_calls(calls):
	breakfast = calls * 0.25
	lunch = calls * 0.35
	dinner = calls * 0.25
	snack = calls * 0.15
	return int(breakfast), int(lunch), int(dinner), int(snack)