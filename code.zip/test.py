from datetime import datetime, date
import django
print(date.today())