from django.urls import path
from WebPage import views
 
urlpatterns = [
    path('', views.index, name='home'),
    path('home/', views.index, name='home'),
    path('home/<int:num1>/<int:num2>/', views.setwater, name='setwater'),
    
	path('login/', views.login, name='login'),
	path('signup/', views.logup, name='signup'),
	path('checklogin/', views.checklogin, name='checklogin'),
	path('setlogin/', views.setlogin, name='setlogin'),
	path('logout/', views.logout, name='logout'),
    
	path('data/', views.data, name='data'),
	path('menu/<str:name>', views.menu, name='menu'),
	path('addmeals/<str:name>', views.addmeals, name='addmeals'),
	
]

handler404 = "WebPage.views.page404"